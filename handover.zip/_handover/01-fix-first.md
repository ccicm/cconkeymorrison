# 01: Fix first

Things on the live site that are wrong or risky. Small, but do them before anything else.

## Checklist

- [ ] **Provisional psychologist.** `_quarto.yml` and `index.qmd` both have a description saying "Connor Conkey-Morrison is a psychologist". Change to "is a provisional psychologist". Search every `.qmd`, `_quarto.yml` and the JSON-LD block for any other "psychologist" without "provisional" and fix it.
- [ ] **KiTeS card (`research/resources.qmd`).** It credits Lester & Michelson (2024), *BMJ Mental Health*, DOI 10.1136/bmjment-2023-300944. That's wrong. KiTeS is Melvin et al. (2019), "The Kids and Teens at School (KiTeS) Framework: An inclusive bioecological systems approach to understanding school absenteeism and school attendance problems", *Frontiers in Education*, https://doi.org/10.3389/feduc.2019.00061. Fetch the full author list from `https://api.crossref.org/works/10.3389/feduc.2019.00061` and fix the card and its Copy APA 7 text.
- [ ] **Other resource cards.** Check the remaining three cards (authors, year, title, journal) against Crossref by DOI. The Elliott & Place year looks wrong. Fix anything that doesn't match.
- [ ] **Emergency numbers (`research/resources.qmd`).** Under the opening paragraph, add: "In an emergency, call 000. Lifeline: 13 11 14 (24/7). Kids Helpline: 1800 55 1800 (ages 5–25, 24/7)."
- [ ] **CV publications (`cv/index.qmd`).** Delete the hand-typed list. Render the list from `data/publications.json` (the weekly ORCID pull, which already has full titles and authors) with a Quarto `pre-render` script that writes an include file (for example `cv/_publications.md`). Format authors APA style: surname, initials. This also removes the wrong "Accepted" on the *AJGP* paper.
- [ ] **Public under-review count.** Remove the `under_review` field from `data/metrics.json` and from the defaults and output in `_scripts/fetch_metrics.py`. Check no page reads it.
- [ ] **Stray file.** Delete `review.patch` from the repo root.

## Done when

- `grep -ri "is a psychologist"` finds nothing
- The KiTeS card shows Melvin et al. (2019), *Frontiers in Education*
- Resources shows the three emergency numbers
- The CV shows 7 publications with full titles and full author lists, and no "Accepted"
- `data/metrics.json` has no `under_review`
- `review.patch` is gone and `quarto render` succeeds
